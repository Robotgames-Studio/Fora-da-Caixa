﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Chekpoint : MonoBehaviour {

	public Vector2 pos; //Propriedade de posição e rotação do Player.
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		pos = transform.position; // A variavel vai receber apenas propriedade de posição.


		//Se clicar F1 pra salvar.
		if (Input.GetKey (KeyCode.F1))
		{
			PlayerPrefs.SetFloat ("x", pos.x); //Vai salvar a posição vertical
			PlayerPrefs.SetFloat ("y", pos.y); //E vai salvar a posição horizontal também.
			print("Chekpoint");
		}


		//Se clicar  Numero 1 pra carregar os dados salvados acima.
		if (Input.GetKey (KeyCode.Alpha1)) 
		{
			//O tranform, nesse caso as propriedades de poisção e rotation do objecto que contém esse script vai receber apenas as posições horizontal e vertical que salvamos,no codigo acima.
			transform.position = new Vector2 (PlayerPrefs.GetFloat("x",pos.x),(PlayerPrefs.GetFloat("z", pos.y)));
			print ("Load");
		}
	}
}
