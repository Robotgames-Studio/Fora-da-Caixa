﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class portalPoint : MonoBehaviour {

	[Header("Pontuação e Objectos pra ganhar as pontuaçoes")]
	int scoreValue = 1; //Valor de cada pontução.
	public GameObject[] bolinhas = new GameObject[4]; //Objectos que iremos usar pra ganhar pontuações.

//	[Header("Pontuação e Objectos balls pra ganhar as pontuaçoes")]
//	public GameObject[] balls = new GameObject[2];


	// Use this for initialization
	void Start () {

	}
	
	// Update is called once per frame
	void Update () {

		
	}

	void OnTriggerEnter2D(Collider2D objs)
	{
		//Se a caixa de pontução colidir com algum objectos que tem as respetivas tags abaixo,a pontuçao do script ScoreManager vai receber o numero de pontuação declarado nesse script.
		switch (objs.transform.tag)
		{
		case "Obj":
			scoreManager.score += scoreValue;
			Destroy (bolinhas [0]);
			break;
		case "Obj2":
			scoreManager.score += scoreValue;
			Destroy (bolinhas [1]);
			break;
		case "Obj3":
			scoreManager.score += scoreValue;
			Destroy (bolinhas [2]);
			break;


		case "Ball1":
			scoreManager.score += scoreValue;
			break;
		case "Ball2":
			scoreManager.score += scoreValue;
			break;

		}
	}


}
