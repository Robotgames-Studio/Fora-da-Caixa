﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class scoreManager : MonoBehaviour {

	public static int score; // Essa é a pontuação atual ou seja current points.
	int savedScore;  //Essa é a pontução Máxima pou seja,a pontuação que será guardada.

	public Text txtScore; //Current points no HUD
//	public Text maxScore; //Maximo de points no HUD
	// Use this for initialization
	void Start () {

		//Se o valor da chave já foi salvo,ou seja se não é a primeira vez a execução do jogo então bota os valores que estão guaradados no savedScore.
		if (PlayerPrefs.HasKey ("Salvo")) {
			savedScore = PlayerPrefs.GetInt ("Salvo");
			
		}
		else //Caso contrário o valor predefinido pra primeira execução do jogo concernente ao savedScore é igual a 0;
		{
			savedScore = 0;
		}


		Debug.Log(PlayerPrefs.GetInt("Salvo")); 

	}
	
	// Update is called once per frame
	void Update () {
		
//		maxScore.text = "Pontução Máxima "+ savedScore;

		txtScore.text = "Pontuação: " + score;

		//Se pountuação atual for maior que pontuação maxima.
		if (score > savedScore)
		{
			savedScore = score; //Então pontuação maxima vai receber a puntuação atual.
			PlayerPrefs.SetInt ("Salvo", savedScore); //E o valor da pontuação maxima será salvo.
		}

	}
}
