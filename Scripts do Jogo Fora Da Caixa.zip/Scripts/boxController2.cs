﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class boxController2 : MonoBehaviour {

	Rigidbody2D ball; //RB2 do Corpo com Script.

	public bool TaNoChao; //Condição.
	public Transform Detectachao; //O componente fisico que usaremos pra detectar.
	public LayerMask WhatIsGround; //Layer de detectar.
	public float raio; //Raio de detectar.


	//Materiais usados pra mudar a cor do Player!
	public MeshRenderer ballsMat;
	public MeshRenderer playerMat;
	public MeshRenderer portalMat;

	//Material do Player.
	public MeshRenderer player;


	// Use this for initialization
	void Start () {

		ball = GetComponent<Rigidbody2D>(); //Pegar o componente RB2D das bolinhas.

	}

	// Update is called once per frame
	void Update () {
		
		//Condição de detectar recebe = ........(.....);
		TaNoChao = Physics2D.OverlapCircle (Detectachao.position, raio, WhatIsGround);


		//Quando Alguns desses buttons for apertado, então o Rigidibody2D do corpo vai receber uma força com alguma direção do vector
		//E a direção será consoante ao Button que estás a pressionar, e simultaneamente com o número velocidade
		//Esse núemro será Multiplicando com a força do corpo em direção do Button pressionado.
		if (Input.GetKey (KeyCode.RightArrow))
		{
			ball.AddForce (Vector2.right * 5);
		}

		else if (Input.GetKey (KeyCode.LeftArrow)) 
		{
			ball.AddForce (Vector2.left * 5);
		}

		if (Input.GetKey (KeyCode.UpArrow) && TaNoChao == true) 
		{
			ball.AddForce (Vector2.up * 15);
		}

		else if (Input.GetKey (KeyCode.DownArrow)) 
		{
			ball.AddForce (Vector2.down * 5);	
		}

	}

	//Se o Player Collider com uma ball ele recebe outro material mudando de cor nesse caso o material da com cor verde.
	void OnCollisionStay2D(Collision2D materials)
	{
		switch (materials.transform.tag) {
		case "Obj":
			player.material = ballsMat.material;
			break;
		case "Obj2":
			player.material = ballsMat.material;
			break;
		case "Obj3":
			player.material = ballsMat.material;
			break;
		}
	}

	//Se o Player sair da colisão com uma ball recebe outro material mudando de cor e regressando pra cor inical o cinzento nesse caso.
	void OnCollisionExit2D(Collision2D materials)
	{
		switch (materials.transform.tag) {
		case "Obj":
			player.material = playerMat.material;
			break;
		case "Obj2":
			player.material = playerMat.material;
			break;
		case "Obj3":
			player.material = playerMat.material;
			break;
			//Se o Player colidir com "portalMat" então recebe outro material nesse caso com a cor do Portal,vermelho;
		case "portalMat":
			player.material = portalMat.material;
			break;
		}
	} 
}
