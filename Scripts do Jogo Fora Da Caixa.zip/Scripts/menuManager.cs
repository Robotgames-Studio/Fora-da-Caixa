﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class menuManager : MonoBehaviour {
	
	[Header("Objectos e Banco de Dados")]
	public GameObject PlataformLoad; //Objecto pra carregarCena
	private int loadint; //Cada numero de cenas pra carregar

	[Header("Layer que iremos detectar num objecto com Box collider")]
	public LayerMask start; //Pra detectar o objecto com boxCollider e a LayerMask referente.
	public LayerMask carregar; //Pra detectar o objecto com boxCollider e a Layer referente.

	[Header("Sensor pra detectar as Layers")]
	public Transform detectNovo;
	public Transform detectLoad;

	[Header("Raio de detectação")]
	public float rayNew; //Raio pra detectar Plataforma com Layer New.
	public float rayLoad;//Raio pra detectar Plataforma com Layer Lad.

	[Header("Condição pra começar")]
	public bool newGamne; //Condição pra começar o jogo na primeira cena
	[Header("Condição pra carregar cena")]
	public bool loadGame; //Condição pra começar o jogo na cena salva.

	Prologo prologo; //Pegar o script de carregar cenas.

	// Use this for initialization
	void Start () {

		//Pegar o numero da cena carregada no primeiro instante apenas.
		loadint = PlayerPrefs.GetInt ("saveScene");
		//Quando o jogo começar a pltaforma de caarregar tem que estar desligada.
		PlataformLoad.SetActive (false);

		//Pegar todos compontes do script de carregar cena.
		prologo = GetComponent<Prologo> ();

		//Se o Banco de dados Loadint tiver um numero da cena salva que for superior a zero,ou superior a primeira cena,então a plataforma de carregar cena estará ativada na cena.
		if (loadint > 0)
		{
			//Ativar Plataforma de carregar certa cena guardada no banco de dados Loadint;
			PlataformLoad.SetActive (true);
		}
	}

	void Update()
	{
		//A condição de novo jogo recebe os seguintes requisitos = o tranform posição do objecto que vai detectar o chão,raio de detectação e a LayerMask de começar.
		newGamne = Physics2D.OverlapCircle (detectNovo.transform.position, rayNew, start);

		//A condição de carregar jogo recebe os seguintes requisitos = o tranform posição do objecto que vai detectar o chão,raio de detectação e a LayerMask de carregar.
		loadGame = Physics2D.OverlapCircle (detectLoad.transform.position, rayLoad, carregar);

		//Se a condição de começar novo jogo for true com todos requisitos.
		if (newGamne == true)
		{
			//CarregaCena
			Application.LoadLevel ("First");
			//Deleta a cena guardada no banco de dados Loadint.
			PlayerPrefs.DeleteKey ("saveScene");
			//Deletar pontuação.
			PlayerPrefs.DeleteKey ("Salvo");

		}

		//Condição pra carregar cena.
		////Se a condição de carregar uma cena salva no banco de dados for true com todos requisitos.
		if (loadGame == true && loadint > 0)
		{
			//Chame a função loadCena
			StartCoroutine ("loadCena");
			print ("carregandoCena");
		}
	}

	IEnumerator loadCena()
	{
		//Esperar um retorno de esperar por 3 segundos
		yield return new WaitForSeconds (3f);
		//E carregar cena que foi salva no banco de dados int.
		SceneManager.LoadScene (loadint);
	}
}
