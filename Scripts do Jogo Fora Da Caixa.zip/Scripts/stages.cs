﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class stages : MonoBehaviour {
	
	[Header("Info que será exibido no HUD e valor da contagem regressiva")]
	public Text vida;
	public float numberVida; //Valor da contagem regressiva

	[Header("Btns que serão exibidos quando o tempo acabar")]
	public GameObject replay;
	public GameObject proximo;
	public GameObject home;

	[Header("Requisito pra passar de nível")]
	public int number;

	// Use this for initialization
	void Start () {
		//Destivar esses buttons no primeiro frame pra não dar bandeira.
		replay.SetActive (false);
		proximo.SetActive (false);
		home.SetActive (false);
		
	}
	
	// Update is called once per frame
	void Update () {

		//Enquanto o jogo estiver a rodar em todos frames o texto que será apresentado no HUD virá juntamente + o valor da contagem regressiva.
		vida.text =" "+numberVida;


		//Se o valor float da contagem regressiva for maior que zero,
		if (numberVida > 0.0f) 
		{
			//Então o valor estará em constante desconto.
			numberVida -= Time.deltaTime;
		} 
		//E depois
		//Se o valor da contagem de vida for descontado até igual ou menor a 1f
		else if (numberVida <= 1f)
		{
			print ("Tempo Acabou");
		//Irá chamar a função congelar do IEnumerator.
			StartCoroutine ("congelar");
		}
	}

	//Função descongelar do IEnumerator
	public IEnumerator congelar()
	{
		//Quando a funçao for chamada
		yield return new WaitForSeconds (3f); //Espere por uns 3 segundos.
		//Em seguida
		Time.timeScale = 0f; //Congela o tempo.
		//Btn de ir no menu.
		home.SetActive (true);
		//Condição pra passar de nivel.
		if (scoreManager.score >= number) //Se a pontução for maior ou igual ao numero quereido,então o botão de passar de nivel será ativado,caso contrário não.
		{
			//E ativa os buttons de carregar próxina cena.
			proximo.SetActive (true);
		} 
		else //Não vai passar de level se for menor que o requisito.
		proximo.SetActive (false);
		replay.SetActive (true); //E tens a opção de recomeçar.

	}
}
