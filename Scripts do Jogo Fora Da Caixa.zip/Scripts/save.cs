﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class save : MonoBehaviour {

	[Header("Texto que será exibido no HUD com seu valor salvo")]
	public Text Save;
	int numberSaved; //Pontuação que será salva no menu inicial.

	// Use this for initialization
	void Start () {
		numberSaved = PlayerPrefs.GetInt ("Salvo"); //No primeiro frame quando abrir a cena do menu,Iremos pegar o valor inteiro da Key "Salvo" e atribuir ao nosso numberSaved.
		Save.text = "Pontuação Máxima: "+numberSaved; //O texto que será mostrado na tela inicial vai receber o numerSaved.
	}
	
	// Update is called once per frame
	void Update () {



		
	}
}
