﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Level : MonoBehaviour {

	[Header("Nome da cena que você quer carregar")]
	public string nameScene;


	//Todas as funções dos buttons em apenas um script.

	//Buttom carregar mesma cena.
	public void same()
	{
		Application.LoadLevel (nameScene);
		Time.timeScale = 1;
	}

	//Carregar uma certa cena cujo nome atribuimos lá no botão em Inspector e o tempo irá será descongelado.
	public void next()
	{
		Application.LoadLevel (nameScene);
		Time.timeScale = 1;
	}

	//Button pra carregar a cena do Menu
	public void menu ()
	{
		Application.LoadLevel (nameScene);
		Time.timeScale = 1;
	}
		

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
