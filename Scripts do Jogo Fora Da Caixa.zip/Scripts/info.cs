﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class info : MonoBehaviour {

//	[Header("Dialogo concernente a pontuação")]
//
//	public GameObject info1;
//	public GameObject info2;
//	[Header("R pra mostrar dialogo sobre a Pontuação")]
//	public int forInfo1;
//	public int forInfo2;
//
//
//	[Header("Dialogo Concernete ao Tempo")]
//	public GameObject info3;
//	public GameObject info4;
//
//
//	// Use this for initialization
//	void Start () {
//
//		info1.SetActive (false);
//		info2.SetActive (false);
//
//	}
//	
//	// Update is called once per frame
//	void Update () {
//
//		if (Input.GetKey (KeyCode.Backspace)) {
//			info1.SetActive (true);
//		}	
//	
//	if (scoreManager.score == forInfo1)
//		{
//			info1.SetActive (true);
////			StartCoroutine("desligarInfo1");
//			Destroy(info1,5f);
//		}
//		else if (scoreManager.score == forInfo2)
//		{
//			info2.SetActive (true);
////			StartCoroutine ("desligarInfo2");
//			Destroy(info2,8f);
//		}
//
//	}

//	IEnumerator desligarInfo1()
//	{
//		yield return new WaitForSeconds (5f);
//		info1.SetActive (false);
//	}
//	IEnumerator desligarInfo2()
//	{
//		yield return new WaitForSeconds (8f);
//		info2.SetActive (false);
//
//	}
		
}
