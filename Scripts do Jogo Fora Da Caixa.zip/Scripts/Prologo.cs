﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Prologo : MonoBehaviour {


	void Update()
	{
		//Se apertar E então.
		if (Input.GetKey (KeyCode.E)) {
			//Chama a função coroutine "indo";
			StartCoroutine ("indo");
			print ("indo");
			PlayerPrefs.DeleteKey ("Salvo"); //Deletar pontuação que está no banco de dados de outro script.
			
		}

		//Pra deletar o save de cena!
		if (Input.GetKey (KeyCode.P)) 
		{  
			//Deleta a cena salva no banco de dados de Loadint;
			PlayerPrefs.DeleteKey ("saveScene");
		}
	}

	//Essa é a função indo.
	 IEnumerator indo()
	{
		//Esperar por três segundos..
		yield return new WaitForSeconds (3f);
		//Carregar a primeira cena.
		Application.LoadLevel ("First");
		//Deletar a cena salva no banco de dados Loadint
		PlayerPrefs.DeleteKey ("saveScene");
		//Deletar pontuação.
		PlayerPrefs.DeleteKey ("Salvo");

	}

	//Função pra colocar num cero button lá no inspector.
	public void ir()
	{
		
		Application.LoadLevel ("Prologo");
	}

	//Pra aplicar no button de exit lá no inspector.

	public void sair()
	{
		Application.Quit ();
	}
		
}
