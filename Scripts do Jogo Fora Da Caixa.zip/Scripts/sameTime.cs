﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class sameTime : MonoBehaviour {

	public LayerMask balls;
	public LayerMask balls2;
	public Transform detector;
	public float ray;

	bool b1;
	bool b2;

	stages stage;

	// Use this for initialization
	void Start () {

		stage = GetComponent<stages> ();
		
	}
	
	// Update is called once per frame
	void Update () {
		b1 = Physics2D.OverlapCircle (detector.transform.position, ray, balls);
		b2 = Physics2D.OverlapCircle (detector.transform.position, ray, balls2);

		if(b1 == true && b2 == true)
		{
			stage.congelar ();
			print ("SameTimeee");
		}
		
	}
}
