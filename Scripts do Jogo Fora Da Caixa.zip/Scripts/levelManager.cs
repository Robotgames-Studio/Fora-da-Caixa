﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class levelManager : MonoBehaviour {

	public GameObject[] ballstodestroy = new GameObject[3];
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	void OnTriggerStay2D(Collider2D metas)
	{
		switch (metas.transform.tag)
		{
		case "Obj":
			StartCoroutine ("passarLevel");
			print ("Passando");
			Destroy (ballstodestroy [0],1f);
			break;
		}
	}

	IEnumerator passarLevel()
	{
		yield return new WaitForSeconds(5f);
		Application.LoadLevel ("Second");
	}
}
